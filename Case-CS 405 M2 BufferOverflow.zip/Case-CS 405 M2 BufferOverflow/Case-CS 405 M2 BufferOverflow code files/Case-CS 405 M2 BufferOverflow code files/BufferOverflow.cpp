// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
/* allows for std:numeric_limits to be used to determine the maximum size of a stream */
#include <limits>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  /*Added std::setw(sizeof(user_input) -1) before user_input to limit how many characters cin will write into the buffer.
  * This prevents buffer overflow by ensuring that no more than 19 characters are read into the 20-character array.
  */
  std::cin >> std::setw(sizeof(user_input) -1) >> user_input;

  /* Checks to see if hte user typed more than the buffer could hold.
  * If a character is waiting in the input stream after the 19 characters, it means the user typed too much data.
  * Notifies the user, clears, and flushes the leftover input so it doesnt interfere with future input.
  */
  if (std::cin.peek() != '\n' && !std::cin.eof()) {
	  std::cout << "Warning: Input is too long. Only the first 19 characters were used." << std::endl;
	  std::cin.clear();
	  std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
