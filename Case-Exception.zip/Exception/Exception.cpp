// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

/* Added a custom exception class that is derived from std::exception.
*  Overriding what() lets the exception provide its own message and lets
*  main() catch this specific type.
*/
class custom_exception : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom exception occured in do_custom_application_logic";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    /* line that allows do_even_more_custom_application_logic to throw an exception.
    *  Alerts the user that an exception was thrown.
    */
    throw std::runtime_error("Exception happened in do_more_custom_application_logic");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    /* Added Try and Catch block to test exception being thrown.
    *  If no exception is thrown, then the program will run and alert the user.
    *  If there is an exception thrown, catch exception and alert user what exception is.
    */
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
        catch (const std::exception & e) {
            std::cout << "Exception caught: " << e.what() << std::endl;
        }

        /* Throwing our custom exception derived from std::exception here so that main() can catch it.
        */
        throw custom_exception();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    /* if statement that throws exception if den is equal to 0.
    *  since dividing a float equal to 0 will not regularly throw an exception,
    *  will need to hardcode rule to throw float type if it is 0.
    */
    if (den == 0) {
        throw std::overflow_error("Divide by zero exception");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    /* Wrapped divide() in a try and catch block sinse do_division() is noexcept and can't let an exception escape.
    *  Catching this type keeps the handler precise to the handler that is expected.
    */
    try {
         auto result = divide(numerator, denominator);
         std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
        }
        catch (const std::overflow_error& e){
            std::cout << "Exception caught: " << e.what() << std::endl;
        }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    /* Wrapped the calls in a try block. Catch blocks are ordered from most specific to least specific.
    *  Added a final safety net so that nothing escapes main() unhandled.
    */
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const custom_exception& e) {
        std::cout << "Custom exception caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Standard exception caught: " << e.what() << std::endl;
    }
    catch (...) {
        std::cout << "Unknown exception caught." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu